<?php
if( !class_exists('Adifier_Elementor_kc_promotion_map') ){
class Adifier_Elementor_kc_promotion_map extends Adifier_Elementor_Base {

}
}
?>