<?php
if( !class_exists('Adifier_Elementor_kc_af_title') ){
class Adifier_Elementor_kc_af_title extends Adifier_Elementor_Base {

}
}
?>