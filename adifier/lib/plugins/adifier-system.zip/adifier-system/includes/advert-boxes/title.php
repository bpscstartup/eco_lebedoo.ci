<h5 class="adv-title">
	<a href="<?php the_permalink() ?>" class="text-overflow" title="<?php echo esc_attr( get_the_title() ) ?>">
		<?php the_title(); ?>
	</a>
</h5>