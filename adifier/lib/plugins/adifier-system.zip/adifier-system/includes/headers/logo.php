<?php adifier_logo_html_wrapper( 'site_logo' ) ?>
<div class="dark-logo-wrap">
<?php
if( $header_style == 'header-2' ){
	adifier_logo_html_wrapper( 'dark_nav_logo', true );
}
?>
</div>